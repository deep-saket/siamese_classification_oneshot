from unicodedata import name
from setuptools import setup, find_packages

setup(name='cvml', 
        version='0.4',
        description='this is a short description',
        long_description='this is a llong description',
        author='Saket',
        packages=['train_eval', 'dl_modules', 'losses', 'dataloaders'])
        # install_requires=['tensorflow'])