import tensorflow as tf
from tensorflow.keras import Model
from tensorflow.keras.layers import Conv2D, BatchNormalization, Conv2DTranspose
from tensorflow.python.keras.engine import training

class ResnetBlock1(Model):
    '''
    Creates a ResNet block.
    The model architechture goes like --
    CONV2D_BLOCK1 >> CONV2D_BLOCK2 >> CONV2D_BLOCK3 + CONV2D_BLOCK1
    '''
    def __init__(self, filters, kernel_size, training, use_bn=False):
        '''
        Instantiated the class
        Arguments --
            filters -- int | number of filters in the conv layers
            kernel_size -- int or tupple of 2 ints | size of the kernl
            training -- boolean | True if training is on and False otherwise
            use_bn -- boolean | default False |  True if batch nnormalization has to be used
        '''
        super(ResnetBlock1, self).__init__(name='')

        ## Computational layers
        self.conv2a = Conv2D(filters, kernel_size, strides=(1,1), activation='relu', padding='same', use_bias=True)
        self.bn2a = BatchNormalization() if use_bn else None

        self.conv2b = Conv2D(filters, kernel_size, strides=(1,1), activation='relu', padding='same', use_bias=True)
        self.bn2b = BatchNormalization() if use_bn else None

        self.conv2c = Conv2D(filters, kernel_size, strides=(1,1), use_bias=True, padding='same')
        self.bn2c = BatchNormalization() if use_bn else None

        ## Other members
        self.training = training
        self.use_bn = use_bn

    def call(self, input_tensor):
        '''
        implements forward propagation
        '''
        x = x1 = self.conv2a(input_tensor)
        if self.use_bn:
            x = self.bn2a(x, training = self.training)

        x = self.conv2b(x)
        if self.use_bn:
            x = self.bn2b(x, training = self.training)

        x = self.conv2c(x)
        if self.use_bn:
            x = self.bn2c(x, training = self.training)

        x += x1

        return tf.nn.relu(x)

class PyramidCascadingModule1(Model):
    '''
    This module is inspired by PCD module proposed in the EDVR paper.
    The model architechture goes like --
    FRAMEt-1 >> CONV2D_BLOCK1t-1 >> CONV2D_BLOCK2t-1
                    +               +          
    FRAMEt >> CONV2D_BLOCK1t >> CONV2D_BLOCK2t
                    +               +         
    FRAMEt+1 >> CONV2D_BLOCK1t+1 >> CONV2D_BLOCK2t+1
                             +          V       
    CONV2D_BLOCK_FINAL << DECONV_BLOCK
        
    CONV2D_BLOCK_FINAL + CONV2D_BLOCK1t-1 >> CONV2D_BLOCK_FEATt-1
    CONV2D_BLOCK_FINAL + CONV2D_BLOCK1t >> CONV2D_BLOCK_FEATt
    CONV2D_BLOCK_FINAL + CONV2D_BLOCK1t+1 >> CONV2D_BLOCK_FEATt+1
    '''
    def __init__(self, training, filters = 32, kernel_size = 3):
        '''
        Instantiates the class.
        Arguments --
            training -- boolean | set True while training, False otherwise
        '''
        super().__init__()

        ## conv2d feature extraction blocks
        self.conv2d1Tm1 = Conv2D(filters, kernel_size, strides=(1,1), activation='relu', padding='same', use_bias=True)
        self.conv2d2Tm1 = Conv2D(filters, kernel_size, strides=(2,2), activation='relu', padding='valid', use_bias=True)

        self.conv2d1T = Conv2D(filters, kernel_size, strides=(1,1), activation='relu', padding='same', use_bias=True)
        self.conv2d2T = Conv2D(filters, kernel_size, strides=(2,2), activation='relu', padding='valid', use_bias=True)

        self.conv2d1Tp1 = Conv2D(filters, kernel_size, strides=(1,1), activation='relu', padding='same', use_bias=True)
        self.conv2d2Tp1 = Conv2D(filters, kernel_size, strides=(2,2), activation='relu', padding='valid', use_bias=True)

        ## deconv block
        self.deconv = Conv2DTranspose(filters, (3, 3), strides=(2,2), activation='relu', padding='same', use_bias=True)

        ## final conv2d
        self.conv2d_final = Conv2D(filters, kernel_size, strides=(1,1), activation='relu', padding='same', use_bias=True)
        # self.conv2d1x1 = Conv2D(filters // 2, 1, strides=(1,1), activation='relu', padding='same', use_bias=True)

        ## conv2d feature blocks
        self.conv2d_featTm1 = Conv2D(filters, kernel_size, strides=(1,1), activation='relu', padding='same', use_bias=True)
        self.conv2d_featT = Conv2D(filters, kernel_size, strides=(1,1), activation='relu', padding='same', use_bias=True)
        self.conv2d_featTp1 = Conv2D(filters, kernel_size, strides=(1,1), activation='relu', padding='same', use_bias=True)

        self.training = training

    def call(self, Xtm1, Xt, Xtp1):
        '''
        Implements forward prop.
        '''
        ## conv2d feature extraction blocks
        Xtm1_1 = Xtm1 = Xtm1_conv2d1 = self.conv2d1Tm1(Xtm1)
        Xtm1 = self.conv2d2Tm1(Xtm1)

        Xt_1 = Xt = Xt_conv2d1 = self.conv2d1T(Xt)
        Xt = self.conv2d2T(Xt)

        Xtp1_1 = Xtp1 = Xtp1_conv2d1 = self.conv2d1Tp1(Xtp1)
        Xtp1 = self.conv2d2Tp1(Xtp1)

        ## deconv block
        X = tf.concat([Xtm1, Xt, Xtp1], -1)
        X = self.deconv(X)
        X = tf.pad(X, tf.constant([[0, 0], [1, 1,], [1, 1], [0, 0]]), 'REFLECT')

        ## final conv2d
        X = tf.concat([X, Xtm1_conv2d1, Xt_conv2d1, Xtp1_conv2d1], -1)
        X = self.conv2d_final(X)

        ## conv2d feature blocks
        Xtm1 = tf.concat([X, Xtm1_1], -1)
        Xtm1 = self.conv2d_featTm1(Xtm1)

        Xt = tf.concat([X, Xt_1], -1)
        Xt = self.conv2d_featT(Xt)

        Xtp1 = tf.concat([X, Xtp1_1], -1)
        Xtp1 = self.conv2d_featTp1(Xtp1)

        return Xtm1, Xt, Xtp1

class TemporalSpatialAttaintion1(Model):
    '''
    This module is inspired by TSA module proposed in the EDVR paper.
    '''
    def __init__(self, training, filters = 32, kernel_size = 3):
        '''
        Instantiates the class.
        Arguments --
            training -- boolean | set True while training, False otherwise
        '''
        super().__init__()

        self.emb_ref_conv = Conv2D(filters, kernel_size, strides=(1,1), activation=None, padding='same', use_bias=True)
        self.fea_conv2d = Conv2D(filters, kernel_size, strides=(1,1), activation=None, padding='same', use_bias=True)
        self.spatial_conv = Conv2D(filters, kernel_size, strides=(1,1), activation=None, padding='same', use_bias=True)
        # self.cat_pool_conv = Conv2D(filters, kernel_size, strides=(1,1), activation=None, padding='same', use_bias=True)
        self.att_add_conv = Conv2D(filters, kernel_size, strides=(1,1), activation=None, padding='same', use_bias=True)

        self.training = training

    def call(self, Xtm1, Xt, Xtp1):
        '''
        Implements forword prop
        '''
        _, H, W, C = Xt.get_shape()

        ## Temporal attention
        alligned_feat = tf.concat([Xtm1, Xt, Xtp1], -1)
        emb_ref = self.emb_ref_conv(Xt)

        cor_l = []
        # cor_l.extend([tf.expand_dims(tf.nn.sigmoid(tf.reduce_sum(emb_ref * Xtm1, axis=-1)), axis=-1)] * C)
        # cor_l.extend([tf.expand_dims(tf.nn.sigmoid(tf.reduce_sum(emb_ref * Xt, axis=-1)), axis=-1)] * C)
        # cor_l.extend([tf.expand_dims(tf.nn.sigmoid(tf.reduce_sum(emb_ref * Xtp1, axis=-1)), axis=-1)] * C)

        alligned_feat_l = []
        alligned_feat_l.append(Xtm1 * tf.expand_dims(tf.nn.sigmoid(tf.reduce_sum(emb_ref * Xtm1, axis=-1)), axis=-1))
        alligned_feat_l.append(Xt * tf.expand_dims(tf.nn.sigmoid(tf.reduce_sum(emb_ref * Xt, axis=-1)), axis=-1))
        alligned_feat_l.append(Xtp1 * tf.expand_dims(tf.nn.sigmoid(tf.reduce_sum(emb_ref * Xtp1, axis=-1)), axis=-1))

        alligned_feat  = tf.concat(alligned_feat_l, axis=-1)

        # cor_prob = tf.expand_dims(tf.nn.sigmoid(tf.concat(cor_l, axis=-1)), axis=-1)
        # cor_prob = tf.concat(cor_l, axis=-1)
        # cor_prob = tf.reshape(cor_prob, [-1, H, W, 3*C])
        # alligned_feat = tf.reshape(alligned_feat, [-1, H, W, 3*C])
        # alligned_feat *= cor_prob

        ## Fusion
        fea = self.fea_conv2d(alligned_feat)
        fea = tf.nn.leaky_relu(fea, alpha=0.1)

        ## Spatial attention
        att = self.spatial_conv(alligned_feat)
        # _, att_h, att_w, _ = att.get_shape()
        att = tf.nn.leaky_relu(att, alpha=0.1)
        # cat_pool = tf.concat([tf.nn.max_pool2d(att, 2, 2, padding='VALID'), tf.nn.avg_pool(att, 2, 2, padding='VALID')], axis=-1)
        # cat_pool = tf.nn.sigmoid(self.cat_pool_conv(cat_pool))
        # up_cat_pool = tf.image.resize(cat_pool, (att_h, att_w))

        att_add = self.att_add_conv(att)
        att_add = tf.nn.leaky_relu(att_add, alpha=0.1)

        att = tf.nn.sigmoid(att)
        # att = fea * att * 2 + up_cat_pool
        att = fea * att * 2 + att_add

        return att