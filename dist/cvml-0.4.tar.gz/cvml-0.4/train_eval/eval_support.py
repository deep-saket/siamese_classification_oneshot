import os
from pytest import yield_fixture

import tensorflow as tf
import numpy as np
from matplotlib import image, pyplot as plt

def psnr(Yp, Yt):
    '''
    this function computes psnr
    '''
    r = tf.image.psnr(Yp, Yt, max_val=1.0)
    
    return r

def ssim_fp(Yp, Yt, filter_size=11,
                          filter_sigma=1.5, k1=0.01, k2=0.03):
    '''
    this function computes ssim, where the image pixel intensity
    is between 0. to 1.
    '''
    r = tf.image.ssim(Yp, Yt, max_val=1.0, filter_size=filter_size,
                          filter_sigma=filter_sigma, k1=k1, k2=k2)
    
    return r

def ssim_int(Yp, Yt, filter_size=11,
                          filter_sigma=1.5, k1=0.01, k2=0.03):
    '''
    this function computes ssim, where the image pixel intensity
    is between 0  to 255
    '''
    r = tf.image.ssim(Yp, Yt, max_val=255, filter_size=filter_size,
                          filter_sigma=filter_sigma, k1=k1, k2=k2)
    
    return r

def calculate_mAB(image):
    '''
    This function calculates mean absolute brightness given an input image batch
    Argument -- 
        image -- ndarray | image batch of shape (n, h, w, c)
    Return -- float | mAB value
    '''
    return tf.reduce_mean(image / 255.)

def multiframe_infer(model, input_frame_dir, t=3, data_format='channel_concat'):
    '''
    Run the model on multiple adjacent images and infers 

    Args --
        model -- tf.keras.Model or loaded tflite model infer function
        input_frame_dir -- str | ptht to the input frame dir
        t -- int | default 3 | seq. of adjacent frames to consider
    Yeilds --
        output -- numpy array | output image
        tdx -- int | index number
    '''

    frame_paths = [os.path.join(input_frame_dir, frame_name) for frame_name in os.listdir(input_frame_dir)]

    for tdx in range(t//2, len(frame_paths) - t//2):
        idx = [i - t//2 for i in range(t+1)]
        frame_paths_t = [frame_paths[i] for i in idx]

         ## load the input frames
        inputs = []
        for input_frame_path in frame_paths_t:
            inputs.append(plt.imread(input_frame_path))

        ## format the input frames
        if data_format == 'channel_concat':
            inputs = np.concatenate(inputs, -1)[np.newaxis, :, :, :]
        elif data_format == 'new_axis':
            inputs = np.stack(inputs, axis=0)
            inputs = np.rollaxis(inputs, axis=0)[np.newaxis, :, :, :, :]

        output = model(image)

        yield output[0], tdx

def adjacent_detect_bbox(model, input_frame_dir, t=2):
    '''
    Run the model on multiple adjacent images and detect s

    Args --
        model -- tf.keras.Model or loaded tflite model infer function
        input_frame_dir -- str | ptht to the input frame dir
        t -- int | default 3 | seq. of adjacent frames to consider
    Yeilds --
        output -- numpy array | output image
        tdx -- int | index number
    '''
    pass

def adjacent_detect(model, input_frame_dir, t=2, success_thresold=2):
    '''
    Run the model on multiple adjacent images and detect s

    Args --
        model -- tf.keras.Model or loaded tflite model infer function
        input_frame_dir -- str | ptht to the input frame dir
        t -- int | default 3 | seq. of adjacent frames to consider
        success_thresold -- int | default 2 | min number of images to be recognised 
                                            successfully
    Yeilds --
        pred_output -- list of numpy array | output logits
        tdx -- int | index number
    '''
    frame_paths = [os.path.join(input_frame_dir, frame_name) for frame_name in os.listdir(input_frame_dir)]

    for tdx in range(len(frame_paths) - t):
        idx = [i for i in range(tdx, tdx + t)]
        frame_paths_t = [frame_paths[i] for i in idx]

        ## load the input frames
        pred_output = []
        for input_frame_path in frame_paths_t:
            input_image = plt.imread(input_frame_path)
            pred_output.append(model)(input_image)       

        yield pred_output, tdx
