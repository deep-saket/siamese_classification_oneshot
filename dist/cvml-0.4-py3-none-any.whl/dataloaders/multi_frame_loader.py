import tensorflow as tf
import numpy as np
import cv2
from matplotlib import pyplot as plt
import os
import random
import glob

class VIDEODATA():
    '''
    Dir Structure :
        DIR_DATA
        |__GT
        |    |__VIDEO1
        |    |  |__0001.png
        |    |  |__0002.png
        |    |  |__ ...
        |    |__VIDEO2
        |    |  |__0001.png
        |    |  |__0002.png
        |    |  |__ ...
        |    |__ ...
        |__INPUT 
            |__VIDEO1
            |  |__0001.png
            |  |__0002.png
            |  |__ ...
            |__VIDEO2
            |  |__0001.png
            |  |__0002.png
            |  |__ ...
            |__ ...
    '''
    def __init__(self, dir_data, n_pre_frames, n_post_frames, batch_size, format='channel_concat', 
                                n_frames_per_video=10, stride=1, shuffle=True, name='', train=True):
        '''
        Initializes the class
        Arguments --
            data_dir -- str | dir where the frames are stored            
            n_pre_frames -- int | number of frames to be considered before the current frame
            n_post_frames -- int | number of frames to be considered after the current frame
            batch_size -- int | size of minibatch to be used while training
            format -- str | default 'channel_concat' | can be one of ['channel_concat', 'new_axis', 'list']
                    'channel_concat' -- concats the input frames sequence in the channel axis
                    'new_axis' -- stacks the input frames along a new axis | at 0th position
                    'list' -- appends the sequence of frames in a list 
            n_frames_per_video -- int | defult 10 | number of frames to be considered per video
            stride -- int | default 1 | stride of the window to be considered while loading seq of frames
            shuffle -- boolean | default True | if True shuffles the dataset after each epoch
            name -- str | name of the dataset | default - ''
            train -- boolean | True if the dataloader will be used for training, False otherwise
        '''
        self.name = name    ## name of the dataset
        self.train = train  ## True if loading data for training, False otherwise
        self.n_pre_frames = n_pre_frames 
        self.n_post_frames = n_post_frames
        self.batch_size = batch_size
        self.stride = stride
        self.n_seq = n_pre_frames + n_post_frames + 1 ## total number of input frames
        self.n_frames_per_video = n_frames_per_video
        print("n_seq:", self.n_seq)
        print("n_frames_per_video:", n_frames_per_video)

        if format not in ['channel_concat', 'new_axis', 'list']:
            print(f"INFO :: datast format is not one of {['channel_concat', 'new_axis', 'list']}. Loding in default format (channel_concat) ")
            format = 'channel_concat'

        self.format = format
        self.shuffle = shuffle
        self.n_frames_video = []

        self._set_filesystem(dir_data)

        self.images_gt, self.images_input = self._scan()

        self.n_video = len(self.images_gt)
        self.n_frame = self.n_video * self.n_frames_per_video
        print("Number of videos to load:", self.n_video)
        print("Number of frames to load:", self.n_frame)

        self.n_batches, self.all_batches = self._prepare_data()  ## contains all the batches, 'n_batches' batches
                                                               ## will be loaded from here while training.
        self.cur_batch_idx = 0  ## index of the batch to be loaded

    def _set_filesystem(self, dir_data):
        '''
        Sets the gt and input dirs
        '''
        print("Loading {} => {} DataSet".format("train" if self.train else "test", self.name))
        self.apath = dir_data
        self.dir_gt = os.path.join(self.apath, 'GT')
        self.dir_input = os.path.join(self.apath, 'INPUT')
        print("DataSet GT path:", self.dir_gt)
        print("DataSet INPUT path:", self.dir_input)

    def _scan(self):
        '''
        Loads absolute path of the images
        '''
        vid_gt_names = sorted(glob.glob(os.path.join(self.dir_gt, '*')))
        vid_input_names = sorted(glob.glob(os.path.join(self.dir_input, '*')))
        assert len(vid_gt_names) == len(vid_input_names), "len(vid_gt_names) must equal len(vid_input_names)"

        images_gt = []
        images_input = []

        for vid_gt_name, vid_input_name in zip(vid_gt_names, vid_input_names):
            if self.train:
                gt_dir_names = sorted(glob.glob(os.path.join(vid_gt_name, '*')))[:self.n_frames_per_video]
                input_dir_names = sorted(glob.glob(os.path.join(vid_input_name, '*')))[:self.n_frames_per_video]
            else:
                gt_dir_names = sorted(glob.glob(os.path.join(vid_gt_name, '*')))
                input_dir_names = sorted(glob.glob(os.path.join(vid_input_name, '*')))
            images_gt.append(gt_dir_names)
            images_input.append(input_dir_names)
            self.n_frames_video.append(len(gt_dir_names))

        return images_gt, images_input

    def _prepare_data(self):
        '''
        Prepares the data for loading. Divides the data into random minibatches.
        Returns number of batches and
        a list of lists containing the absolute path of the images to be loaded 
        list structure --
            [[batch1], [batch2], ...]
            batch1 - [[record1], [record2], ...]    | till self.n_batches
            record1 - [[INPUT], GT]
            INPUT - [[frame_t-1, frame_t, frame_t+1]] | in this example self.n_pre_frames = self.n_post_frames = 1
            GT - frame_t
        '''
        all_records = []
        all_batches = []
        
        ## iterate over number of videos
        for vdx in range(self.n_video):
            frames_in_vid = len(self.images_gt[vdx])

            ## iterate over number of frames starting from self.n_pre_frames -1 to frames_in_vid - self.n_post_frames
            ## with stride self.stride
            for fdx in range(self.n_pre_frames - 1, frames_in_vid - self.n_post_frames, self.stride):
                batch = []
                input_frames = []

                ## load the input frames
                for tdx in range(fdx - self.n_pre_frames, fdx + self.n_post_frames + 1):
                    input_frames.append(self.images_input[vdx][tdx])

                ## load the gt frame
                gt_frame = self.images_gt[vdx][fdx]
                                
                ## add them to all_batches
                batch.append(input_frames)
                batch.append(gt_frame)
                all_records.append(batch)
        
        ## shuffle all_batches
        random.shuffle(all_records)
        
        ## calculate number of batches
        n_records = len(all_records)
        n_batches = (n_records // self.batch_size) + 1
        self.m = n_records

        ## iterate over the all_records and put them in batches
        for bdx in range(n_batches - 1):
            start_idx = bdx * self.batch_size
            end_idx = start_idx + self.batch_size if (start_idx + self.batch_size) < n_records else n_records

            batch = all_records[start_idx : end_idx]

            all_batches.append(batch)

        ## return all_batches
        return n_batches, all_batches

    def get_record(self, record):
        '''
        Loads 1 record and returns the numpy array
        Argumets --
            record --list of paths of images to be loaded |
                    structure - record - [[INPUT], GT]
                                INPUT - [[frame_t-1, frame_t, frame_t+1]] | 
                                        in this example self.n_pre_frames = self.n_post_frames = 1
                                GT - frame_t
        Returns --
            inputs -- list ndarrays | imput frames
            gt -- ndarray input image
        '''
        ## load the input frames
        inputs = []
        for input_frame_path in record[0]:
            inputs.append(plt.imread(input_frame_path))

        ## format the input frames
        if self.format == 'channel_concat':
            inputs = np.concatenate(inputs, -1)
        elif self.format == 'new_axis':
            inputs = np.stack(inputs, axis=0)
            inputs = np.rollaxis(inputs, axis=0)

        ## load the gt frame
        gt = plt.imread(record[1])

        ## return the frames
        return inputs, gt

    def get_batch(self, batch):
        '''
        Loads 1 batch and returns the numpy array
        Argumets --
            batch --list of paths of images to be loaded |
                    structure - batch - [record1, record2, ...] 
                                record1 - [[INPUT], GT]
                                INPUT - [[frame_t-1, frame_t, frame_t+1]] | 
                                        in this example self.n_pre_frames = self.n_post_frames = 1
                                GT - frame_t
        Returns --
            inputs -- list ndarrays | imput frames
            gt -- ndarray input image
        '''
        batch_inputs = []
        batch_gt = []

        for record in batch:
            inputs, gt = self.get_record(record)

            batch_inputs.append(inputs)
            batch_gt.append(gt)
        
        if self.format == 'channel_concat' or self.format == 'new_axis':
            batch_inputs = np.stack(batch_inputs, axis=0)
            batch_inputs = np.rollaxis(batch_inputs, axis=0)
        
        batch_gt = np.stack(batch_gt, axis=0)
        batch_gt = np.rollaxis(batch_gt, axis=0)

        return batch_inputs, batch_gt

    def get_data(self):
        '''
        Loads the next minibatch and returns it
        '''
        if self.cur_batch_idx >= self.n_batches - 1:
            self.cur_batch_idx = 0
            if self.shuffle:
                random.shuffle(self.all_batches)
        
        # print('dddd', len(self.all_batches), self.n_batches, self.cur_batch_idx)
        
        # print(self.all_batches)
        
        inputs, gt = self.get_batch(self.all_batches[self.cur_batch_idx])
        self.cur_batch_idx += 1

        return {
                'input_batch' : inputs,
                'gt_batch' : gt
            }

    def count_minibatches(self):
        '''
        Returns number of minibatches in the training set.
        '''
        return self.n_batches
