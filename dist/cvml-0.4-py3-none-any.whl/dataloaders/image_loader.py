import tensorflow as tf
import numpy as np
import cv2
from matplotlib import pyplot as plt
from collections import OrderedDict
import math
import os
import random
import pista
import xml.etree.ElementTree
from scipy import ndimage

def normalize(data_batch):
    '''
    Normalizes the inopt batch
    '''
    norm_batch = []

    norm_batch.append(data_batch[0] / 255.0)
    norm_batch.append(data_batch[-1] / 255.0)

    return tuple(norm_batch)

class DataLoader:
    '''
    Loads the datset.
    '''
    def __init__(self, batch_size, dataset_path, grayscale=False, rotate=False, blur=False, size=(512, 512)):
        '''
        Initialize the class.
        Args ::
            batch_size -- int | number of examples to be processed in one example
            dataset_path -- str | tfrecord dir
            dataset_info_path -- str | info.txt path
        '''
        self._batch_size = batch_size
        self._dataset_path = dataset_path
        self._fetched_batch = 0
        self.grayscale = grayscale
        self.rotate = rotate
        self.blur = blur
        self.size = size
        
        self.blurred_image_dir = os.path.join(self._dataset_path, 'blur')
        self.gt_image_dir = os.path.join(self._dataset_path, 'gt')

        self.dataset = self._prepare_data()
        random.shuffle(self.dataset)
        
        self.m = len(os.listdir(self.blurred_image_dir)) - 1
        
    def _prepare_data(self):
        '''
        Loads examples into memory from tfrecord.
        '''
        gt_images = []
        blurred_images = []
        
        for file_name in os.listdir(self.blurred_image_dir):
            if file_name.split('.')[-1] not in ['jpg', 'jpeg', 'JPG', 'png', 'PNG', 'tiff', 'tif', 'TIFF', 'TIF']:
                continue
            blurred_image_path = os.path.join(self.blurred_image_dir, file_name)
            gt_image_path = os.path.join(self.gt_image_dir, file_name)
            
            gt_images.append(gt_image_path)
            blurred_images.append(blurred_image_path)
            
        return pista.random_mini_batches_from_SSD(blurred_images, gt_images, self._batch_size)
        
    def _get_items(self, blurred_image_paths, gt_image_paths):
        
        blurred_images = []
        gt_images = []
        for i in range(len(blurred_image_paths)):
            blurred_image, gt_image = self._get_item(blurred_image_paths[i], gt_image_paths[i])
            blurred_images.append(blurred_image)
            gt_images.append(gt_image)
            
        blurred_images = np.stack(blurred_images, axis=3)
        blurred_images = np.rollaxis(blurred_images, 3)
        
        gt_images = np.stack(gt_images, axis=0)
        gt_images = np.rollaxis(gt_images, axis=0)
        
        return blurred_images, gt_images
            
         
    def _get_item(self, blurred_image_path, gt_image_path):      
        blurred_image = plt.imread(blurred_image_path)
        gt_image = plt.imread(gt_image_path)

        h, w, _ = blurred_image.shape
        
        if blurred_image.shape[-1] > 3:
            blurred_image = cv2.cvtColor(blurred_image, cv2.COLOR_RGBA2RGB)
        if gt_image.shape[-1] > 3:
            gt_image = cv2.cvtColor(gt_image, cv2.COLOR_RGBA2RGB)        
        
        if self.grayscale:
            blurred_image = cv2.cvtColor(blurred_image, cv2.COLOR_RGB2GRAY)[:, :, np.newaxis]
            gt_image = cv2.cvtColor(gt_image, cv2.COLOR_RGB2GRAY)[:, :, np.newaxis]
        
        blurred_image = tf.image.resize(blurred_image, self.size)
        gt_image = tf.image.resize(gt_image, self.size)
        
        if (blurred_image_path.split('.')[-1] != 'png' and blurred_image_path.split('.')[-1] != 'PNG') or blurred_image.numpy().max() > 2.:
            blurred_image = (blurred_image / 255.)
        if (gt_image_path.split('.')[-1] != 'png' and gt_image_path.split('.')[-1] != 'PNG') or gt_image.numpy().max() > 2.:
            gt_image = (gt_image / 255.)
    
        return blurred_image, gt_image
    
    def get_data(self):
        '''
        fetch one batch at a time
        '''
        if self._fetched_batch >= self.count_minibatches():
            self.dataset = self._prepare_data()
            random.shuffle(self.dataset)
            self._fetched_batch = 0

        ## fetch 1 batch at a time from the iterator
        data_batch_paths = self.dataset[self._fetched_batch]
        self._fetched_batch += 1
        
        blurred_image_path, gt_image_path = data_batch_paths
        blurred_image, gt_image = self._get_items(blurred_image_path, gt_image_path)
        data_batch = {'blurred_images': blurred_image, 'gt_images': gt_image}

        return data_batch

    def count_minibatches(self):
        '''
        Counts number of minibatches.
        '''
        return math.ceil(self.m/self._batch_size)


class TripletLoader:
    '''
    Loads the datset.

    Returns as
    [
        (
            ndarray of share BATCH_SIZExHxWxC, 
            ndarray of share BATCH_SIZExHxWxC, 
            ndarray of share BATCH_SIZExHxWxC
        )
        ndarray of shape 1xBATCH_SIZE
    ]
    '''
    def __init__(self, batch_size, dataset_path, grayscale=False, rotate=False, blur=False, size=(224, 224), visualize=False):
        '''
        Initialize the class.
        Args ::
            batch_size -- int | number of examples to be processed in one example
            dataset_path -- str | tfrecord dir
            dataset_info_path -- str | info.txt path
        '''
        self._batch_size = batch_size
        self._dataset_path = dataset_path
        self._fetched_batch = 0
        self.grayscale = grayscale
        self.rotate = rotate
        self.blur = blur
        self.size = size
        self.visualize = visualize

        ## get number of classes present in the dataset
        self.classes = os.listdir(dataset_path)
        self.n_classes = len(self.classes)
        self.class_number_dict = {self.classes[i] : i for i in range(len(self.classes))}

        ## class dir dict
        self.class_dict = {klass : os.path.join(dataset_path, klass) for klass in self.classes}
        
        ## prepare the dataset
        self.dataset = self._prepare_data()
        random.shuffle(self.dataset)
                
    def _prepare_data(self):
        '''
        Loads examples into memory from tfrecord.
        '''
        anchor_image_paths = []
        pos_image_paths = []
        neg_image_paths = []
        lables = []

        m = 0
        for klass_name, klass_path in self.class_dict.items():
            m += 1
            file_names = os.listdir(klass_path)

            for file_name in file_names:
                if file_name.split('.')[-1] not in ['jpg', 'jpeg', 'JPG', 'png', 'PNG', 'tiff', 'tif', 'TIFF', 'TIF']:
                    continue
                
                anchor_image_path = os.path.join(klass_path, file_name)

                remaining_pos = list(file_names)
                remaining_pos.remove(file_name)
                random.shuffle(remaining_pos)
                pos_image_path = os.path.join(klass_path, remaining_pos[0])

                remaining_klass = list(self.classes)
                remaining_klass.remove(klass_name)
                random.shuffle(remaining_klass)
                remaining_klass_image_paths = os.listdir(self.class_dict[remaining_klass[0]])
                random.shuffle(remaining_klass_image_paths)
                neg_image_path = os.path.join(self.class_dict[remaining_klass[0]], remaining_klass_image_paths[0])
            
                pos_image_paths.append(pos_image_path)
                anchor_image_paths.append(anchor_image_path)
                neg_image_paths.append(neg_image_path)

                lables.append(self.class_number_dict[klass_name])
        
        self.m = m
        return pista.random_mini_batches_from_SSD_tripple(anchor_image_paths, pos_image_paths, neg_image_paths, lables, self._batch_size)

    def show_triplet(self, pairs):
        anchor, positive, negative = pairs
        fig, ax = plt.subplots(10,3, figsize=(10,20))
        
        for i in range(10):
            ax[i, 0].imshow((anchor[i]))
            ax[i, 1].imshow((positive[i]))
            ax[i, 2].imshow((negative[i]))
            ax[i, 0].set_title("anchor")
            ax[i, 1].set_title("Positive")
            ax[i, 2].set_title("Negative")
            ax[i, 0].axis('off')
            ax[i, 1].axis('off')
            ax[i, 2].axis('off')
        
    def _get_items(self, image_paths, labels):
        ancchor_images = []
        pos_images = []
        neg_images = []

        for i in range(len(labels)):
            ancchor_image_path = image_paths[0][i]
            pos_image_path = image_paths[1][i]
            neg_image_path  = image_paths[2][i]
            # print(2, image_paths[i])
            ancchor_image, pos_image, neg_image = self._get_item((ancchor_image_path, pos_image_path, neg_image_path))
            # if self.visualize:
            #    self.show_triplet((ancchor_image, pos_image, neg_image))
            ancchor_images.append(ancchor_image)
            pos_images.append(pos_image)
            neg_images.append(neg_image)
            
        ancchor_images = np.stack(ancchor_images, axis=3)
        ancchor_images = np.rollaxis(ancchor_images, 3)
        
        pos_images = np.stack(pos_images, axis=0)
        pos_images = np.rollaxis(pos_images, axis=0)

        neg_images = np.stack(neg_images, axis=0)
        neg_images = np.rollaxis(neg_images, axis=0)
        
        return (ancchor_images, pos_images, neg_images), np.array(labels).reshape((1, len(labels)))
            
         
    def _get_item(self, image_path):      
        ancchor_image_path, pos_image_path, neg_image_path = image_path
        ancchor_image = plt.imread(ancchor_image_path)
        pos_image = plt.imread(pos_image_path)
        neg_image = plt.imread(neg_image_path)

        h, w, _ = ancchor_image.shape
        
        if ancchor_image.shape[-1] > 3:
            ancchor_image = cv2.cvtColor(ancchor_image, cv2.COLOR_RGBA2RGB)
        if pos_image.shape[-1] > 3:
            pos_image = cv2.cvtColor(pos_image, cv2.COLOR_RGBA2RGB)        
        if neg_image.shape[-1] > 3:
            neg_image = cv2.cvtColor(neg_image, cv2.COLOR_RGBA2RGB)        
        
        if self.grayscale:
            ancchor_image = cv2.cvtColor(ancchor_image, cv2.COLOR_RGB2GRAY)[:, :, np.newaxis]
            pos_image = cv2.cvtColor(pos_image, cv2.COLOR_RGB2GRAY)[:, :, np.newaxis]
            neg_image = cv2.cvtColor(neg_image, cv2.COLOR_RGB2GRAY)[:, :, np.newaxis]
        
        ancchor_image = tf.image.resize(ancchor_image, self.size)
        pos_image = tf.image.resize(pos_image, self.size)
        neg_image = tf.image.resize(neg_image, self.size)
        
        if (ancchor_image_path.split('.')[-1] != 'png' and ancchor_image_path.split('.')[-1] != 'PNG') or ancchor_image.numpy().max() > 2.:
            ancchor_image = (ancchor_image / 255.)
        if (pos_image_path.split('.')[-1] != 'png' and pos_image_path.split('.')[-1] != 'PNG') or pos_image.numpy().max() > 2.:
            pos_image = (pos_image / 255.)
        if (neg_image_path.split('.')[-1] != 'png' and neg_image_path.split('.')[-1] != 'PNG') or neg_image.numpy().max() > 2.:
            neg_image = (neg_image / 255.)
    
        return ancchor_image, pos_image, neg_image
    
    def get_data(self):
        '''
        fetch one batch at a time
        '''
        if self._fetched_batch >= len(self.dataset):
            self.dataset = self._prepare_data()
            random.shuffle(self.dataset)
            self._fetched_batch = 0

        ## fetch 1 batch at a time from the iterator
        data_batch_paths = self.dataset[self._fetched_batch]
        self._fetched_batch += 1
        
        image_paths, labels = data_batch_paths
        images, labels = self._get_items(image_paths, labels)
        data_batch = {'images': images, 'labels': labels}

        return data_batch
    
    def count_minibatches(self):
        '''
        Returns number of minibatches.
        '''
        return len(self.dataset)