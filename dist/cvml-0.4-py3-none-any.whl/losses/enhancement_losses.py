import tensorflow as tf
from tensorflow.keras.losses import *
import numpy as np

def vgg_layers(layer_names):
        """ Creates a vgg model that returns a list of intermediate output values."""
        # Load our model. Load pretrained VGG, trained on imagenet data
        vgg = tf.keras.applications.VGG19(include_top=False, weights='imagenet')
        vgg.trainable = False
        
        outputs = [vgg.get_layer(name).output for name in layer_names]

        model = tf.keras.Model([vgg.input], outputs)
        return model

def mae_mssim_cost(y_true, y_pred):
    '''
    Computes 'alpha' * 'mean ssim' and '(1 - alpha)' * ' mean absolute error'.
    alpha = 0.84
    '''
    alpha = tf.constant(0.84)
    mssim = alpha*(1 - tf.image.ssim_multiscale(y_true, y_pred,max_val = 1.0, filter_size = 3))
    mse = tf.metrics.mae(y_true, y_pred)
    loss = tf.reduce_mean(mssim) + (1 - alpha) * tf.reduce_mean(mse)

    return loss

def mse_cost(y_true, y_pred):
    '''
    Computes mean square error cost
    '''
    loss = tf.reduce_mean((y_true - y_pred) ** 2)
    return loss

def se_cost(y_true, y_pred):
    '''
    Computes mean square error cost
    '''
    loss = tf.reduce_sum((y_true - y_pred) ** 2)
    return loss

STYLE_LAYERS = ['block1_conv1',
                'block2_conv1',
                'block3_conv1', 
                'block4_conv1', 
                'block5_conv1'], 
CONTENT_LAYERS = ['block5_conv2']

def perceptual_content_cost(y_true, y_pred, vgg19):
    '''
    Computes perceptual loss (only content) from VGG19 model.
    Arguments --
        y_true -- tensor of shape (batch_size, h, w, c) | ground truth
        y_pred -- tensor of shape (batch_size, h, w, c) | prediction
        vgg19 -- keras.Model | vgg19 model to be used, the output of the mode
                        is vgg19 layers from which loss will be calculated
        layers -- list of str | default = ['block5_conv2'] 
                        | list of all the layers from vgg19 to be used
                        wihile calculating the content loss
    Returns --
        loss -- float | value of the calculated loss
    '''  
    ## function to compute content loss
    def content_loss(content_ytrue, content_ypred):
        '''
        Computes loss between content layer outoputs if the 
        '''
        loss = 0
        if type(content_ytrue) == list:
            loss = tf.add_n([tf.reduce_mean((content_ytrue[i] - content_ypred[i]) ** 2) 
                                 for i in len(content_ytrue)])
        else:
            loss = tf.reduce_mean((content_ytrue - content_ypred) ** 2)
        return loss

    ## preprocess y_true and y_pred for vgg19
    y_true = tf.keras.applications.vgg19.preprocess_input(y_true)
    y_pred = tf.keras.applications.vgg19.preprocess_input(y_pred)

    ## calculate the activations of the layers stored in the layer list
    ## both for y_true and y_pred 
    y_true_act = vgg19(y_true)
    y_pred_act = vgg19(y_pred)

    ## calculate content loss
    loss = content_loss(y_true_act, y_pred_act)

    return loss

def perceptual_style_content_cost(y_true, y_pred, vgg19, style_w = 1e-2, content_w = 1e4):
    '''
    Computes perceptual loss from VGG19 model.
    Arguments --
        y_true -- tensor of shape (batch_size, h, w, c) | ground truth
        y_pred -- tensor of shape (batch_size, h, w, c) | prediction
        style_w -- float | default = 1e-2 | weight of the style loss
        content_w -- float | default = 1e4 | weight of the content loss
        vgg19 -- keras.Model | vgg19 model to be used, the output of the mode
                        is vgg19 layers from which loss will be calculated
    Returns --
        total_loss -- float | value of the calculated loss
    '''
    ## number of layers to be considered for calculation of the loss
    num_content_layers = len(CONTENT_LAYERS)
    num_style_layers = len(STYLE_LAYERS)
 
    ## function to compute gram matrix
    def gram_matrix(input_tensor):
        '''
        Given an input tensor, this function computes gram matrix
        '''
        result = tf.linalg.einsum('bijc,bijd->bcd', input_tensor, input_tensor)
        input_shape = tf.shape(input_tensor)
        num_locations = tf.cast(input_shape[1]*input_shape[2], tf.float32)
        return result/(num_locations)
    
    ## function to compute content loss
    def loss(ytrue, ypred):
        '''
        Computes loss between content layer outoputs if the 
        '''
        loss = 0
        if type(ytrue) == list:
            loss = tf.add_n([tf.reduce_mean((ytrue[i] - ypred[i]) ** 2) 
                                 for i in len(ytrue)])
        else:
            loss = tf.reduce_mean((ytrue - ypred) ** 2)
            
        return loss

    ## preprocess y_true and y_pred for vgg19
    y_true = tf.keras.applications.vgg19.preprocess_input(y_true)
    y_pred = tf.keras.applications.vgg19.preprocess_input(y_pred)

    ## calculate the activations of the layers stored in the layer list
    ## both for y_true and y_pred 
    y_true_act = vgg19(y_true)
    y_pred_act = vgg19(y_pred)

    ## prepare content inputs
    y_true_content = y_true_act[num_style_layers: ]
    y_pred_content = y_pred_act[num_style_layers: ]

    ## prepare style inputs
    y_true_style = [gram_matrix(act) for act in y_true_act[ :num_style_layers]]
    y_pred_style = [gram_matrix(act) for act in y_pred_act[ :num_style_layers]]

    ## calculate content loss and style loss
    content_loss = loss(y_true_content, y_pred_content)
    style_loss = loss(y_true_style, y_pred_style)

    ## compute total loss
    total_loss = (style_w / num_style_layers) * style_loss + (content_w / num_content_layers) * content_loss

    return total_loss

def exposure_control_loss(Y_true, Y_pred, rsize=16, E=0.6):
    '''
    1. This loss helps restraining under-/over-exposed regions of the input image.
    2. This is also a no reference loss function originally implemented by Guo1 et. al. in the paper Zero DCE.
    N.B. - I have found that this loss function can be implented in other image generation tasks and
        it has the ability to get rid of artifacts (blocking artifacts to be specific)
    Args ::
        Y_true - tensor | gt image at various iterations
        Y_pred - tensor | reformed image (output) at various iterations
        rsize - int | default 16 | denotes the size of the window to adjust the intensity | an hyperparameter
                            that can be tuned
    '''
    Y_pred_avg_intensity = tf.reduce_mean(tf.nn.avg_pool(Y_pred, [1, rsize, rsize, 1], [1, 1, 1, 1], padding='VALID', name='avg_pool_for_exposure_control_loss'), 1)
    Y_true_avg_intensity = tf.reduce_mean(tf.nn.avg_pool(Y_true, [1, rsize, rsize, 1], [1, 1, 1, 1], padding='VALID', name='avg_pool_for_exposure_control_loss'), 1)
    exp_loss = tf.reduce_mean(tf.math.abs(Y_pred_avg_intensity - Y_true_avg_intensity)) ## can be used mse instead of mae

    return exp_loss

def spatial_consistency_loss(Y_true, Y_pred, rsize=4):
    '''
    This loss function encourages spatial coherence of the enhanced image through preserving the difference 
    of neighboring regions between the input image and its enhanced version. 
    Arguments : 
        Y_true - tensor | gt image taken
        Y_pred - tensor | reformed image (output) at various iterations
        rsize - int | default 16 | denotes the size of the window to copare the difference
    ''' 
    consistency_kernel = tf.constant(np.array([[[[ 0.,  0.,  0.,  0.]],
                [[-1.,  0.,  0.,  0.]],
                [[ 0.,  0.,  0.,  0.]]],

             [[[ 0.,  0., -1.,  0.]],
                [[ 1.,  1.,  1.,  1.]],
                [[ 0.,  0.,  0., -1.]]],

            [[[ 0.,  0.,  0.,  0.]],
                [[ 0., -1.,  0.,  0.]],
                [[ 0.,  0.,  0.,  0.]]]]), dtype=tf.dtypes.float32)
    
    ## N.B. the array [0.3, 0.59, 0.1] is also a hyper-parameter, which can be tuned.
    to_gray = tf.constant(np.array([1., 1., 1.]).reshape((1, 1, 3, 1)), dtype=tf.dtypes.float32)

    enh_gray =  tf.nn.conv2d(Y_pred, to_gray, strides=[1, 1, 1, 1], padding='VALID', name='conv2D-scl1')
    orig_gray =  tf.nn.conv2d(Y_true, to_gray, strides=[1, 1, 1, 1], padding='VALID', name='conv2D-scl2')
    
    enh_pool = tf.nn.avg_pool(enh_gray, ksize=[1, 4, 4, 1], strides=[1, 4, 4, 1], padding='VALID')
    orig_pool = tf.nn.avg_pool(orig_gray, ksize=[1, 4, 4, 1], strides=[1, 4, 4, 1], padding='VALID')
    
    cost = tf.reduce_mean((tf.nn.conv2d(enh_pool, consistency_kernel, strides=[1, 1, 1, 1], padding='VALID') - tf.nn.conv2d(orig_pool, consistency_kernel, strides=[1, 1, 1, 1], padding='VALID')) ** 2)
    
    return cost

def exposure_control_loss_unsupervised(enhances, rsize=16, E=0.6):
    '''
    1. This loss helps restraining under-/over-exposed regions of the input image.
    2. This is also a no reference loss function originally implemented by Guo1 et. al. in the paper Zero DCE.
    N.B. - I have found that this loss function can be implented in other image generation tasks and
        it has the ability to get rid of artifacts (blocking artifacts to be specific)
    Args ::
        enhances - tensor | reformed image (output) at various iterations
        rsize - int | default 16 | denotes the size of the window to adjust the intensity | an hyperparameter
                            that can be tuned
        E - float | default 0.6 | the av. intensity of the ouput image | this hypeerparameter can also be tuned
                            but I have found that 0.6 give the best results as suggested by the authors
    '''
    avg_intensity = tf.reduce_mean(tf.nn.avg_pool(enhances, [1, rsize, rsize, 1], [1, 1, 1, 1], padding='VALID', name='avg_pool_for_exposure_control_loss'), 1)
    exp_loss = tf.reduce_mean(tf.math.abs(avg_intensity - E)) ## can be used mse instead of mae

    return exp_loss

def alpha_total_variation(A):
    '''
    1. This function calculates total variation loss. 
    2. Total Variation or TV loss is a no reference loss function originally implemented by Guo1 et. al. in the
        paper Zero DCE.
    3. The intuition behind this loss is to preserve the monotonicity relations between neighboring pixels.
    Args ::
        A - tensor | image transformation coefs
    Return ::
        loss - float | the value of the loss
    '''
    delta_h = A[:, 1:, :, :] - A[:, :-1, :, :]
    delta_w = A[:, :, 1:, :] - A[:, :, :-1, :]


    tv = tf.math.reduce_mean(tf.math.reduce_mean(tf.math.abs(delta_h), 2), 1) + tf.math.reduce_mean(tf.math.reduce_mean(tf.math.abs(delta_w), 2), 1)
    loss = tf.math.reduce_mean(tf.math.reduce_sum(tv, 1)) # / (tf.shape(A)[1] / 3))

    return loss

def color_constency_loss(enhances):
    '''
    This loss function is inspired by the Gray-World color constancy hypothesis which states that
    color in each sensor channel averages to gray over the entire image.
    Args ::
        enhances - tensor | reformed image (output) at various iterations
    '''
    plane_avg = tf.reduce_mean(tf.reduce_mean(enhances, 1), 2)
    col_loss = ((plane_avg[:, 0] - plane_avg[:, 1]) ** 2 ) + ((plane_avg[:, 1] - plane_avg[:, 2]) ** 2 ) + ((plane_avg[:, 2] - plane_avg[:, 0]) ** 2 )
    col_loss = tf.reduce_mean(col_loss)

    return col_loss

def triplet_loss(Y_pred, margin=0.5):
    '''
    Computes triplet cost
    '''
    # The output of the network is a tuple containing the distances
    # between the anchor and the positive example, and the anchor and
    # the negative example.
    def _contrastive_loss(y_true, y_pred):
        return tfa.losses.contrastive_loss(y_true, y_pred)
        
    loss = tf.convert_to_tensor(0,dtype=tf.float32)
    g = tf.constant(1.0, shape=[1], dtype=tf.float32)
    h = tf.constant(0.0, shape=[1], dtype=tf.float32)
    
    ap_distance, an_distance = Y_pred
    # print(ap_distance, an_distance)
    # loss_query_pos = tf.reduce_mean(_contrastive_loss(g, ap_distance))
    # loss_query_neg = tf.reduce_mean(_contrastive_loss(h, an_distance))
    loss = ap_distance - an_distance
    
    # Computing the Triplet Loss by subtracting both distances and
    # making sure we don't get a negative value.
    loss = tf.maximum(loss + margin, 0.0)
    
    return loss